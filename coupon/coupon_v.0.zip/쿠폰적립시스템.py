#!/usr/bin/env python
# coding: utf-8

# In[22]:


from tkinter import *
import tkinter
import pymysql

# db 연결
# 전역변수 선언
conn = None
cur=None
# 테이블 행
row=None

phone = ""
count = ""

# DB 정보
conn = pymysql.connect(host='127.0.0.1', user='root', password='woooo', 
                       db='coupon', charset='utf8')
cur = conn.cursor()
#---------------------------------------------------------------------------

# 창 생성
win = Tk()
# 창 크기 설정
win.geometry("330x300")
win.title("쿠폰적립 시스템")
win.option_add("*Fomt", "맑은고딕 25")
# win.configure(bg="red")

# 쿠폰 적립(신규 경우 등록)
def update_db():
    a = ent1.get()
    if len(a) == 11:
        cur.execute("SELECT * FROM customer WHERE phone LIKE '%" + a + "%'")
        row=cur.fetchone()
        # 데이터X = 신규
        if row == None:
            cur.execute("INSERT INTO customer(`phone` , `count`) values('"+a+"',1)")
            conn.commit() # 등록 커밋
            result.config(text="고객 등록 완료!")
            result.grid(column=2, row=3, pady=10)

            cur.execute("SELECT * FROM customer WHERE phone LIKE '%" + a + "%'")
            row=cur.fetchone()
            phone = row[0]
            count = row[1]

            lab2.config(text="%s \t %d" %(phone, count) + "\n")
            lab2.grid(column=2, row=4)
            
        else :
            cur.execute("UPDATE customer SET count = count + 1 WHERE phone="+ a)
            cur.execute("SELECT * FROM customer WHERE phone LIKE '%" + a + "%'")
            conn.commit() # 업데이트 커밋
            result.config(text="쿠폰 적립 완료!")
            result.grid(column=2, row=3, pady=10)

            row=cur.fetchone()
            phone = row[0]
            count = row[1]

            lab2.config(text="%s \t %d" %(phone, count) + "\n")
            lab2.grid(column=2, row=4)
        
    else:
        result.config(text="전화번호를 다시 입력해주세요")
        result.grid(column=2, row=3, pady=10)
        lab2.config(text='')
    
# 쿠폰 정보 조회    
def select_db():
    a = ent1.get()
    if len(a) == 11:
        answer=''
        cur.execute("SELECT * FROM customer WHERE phone LIKE '%" + a + "%'")
        result.config(text="전화번호        쿠폰개수\n-------------------------\n")
        result.grid(column=2, row=3, pady=10)
        
        while(True):
            row=cur.fetchone() #한 줄씩
            if row==None :
                break
            phone = row[0]
            count = row[1]
            answer += "%s \t %d" %(phone, count) + "\n"
            
        lab2.config(text=answer)
        lab2.grid(column=2, row=4)
        
    else :
        result.config(text="전화번호를 다시 입력해주세요")
        result.grid(column=2, row=3, pady=10)
        lab2.config(text='')
            
# 라벨 : 조회
lab = Label(win)
lab.config(text="전화번호 :")
lab.grid(column=1, row=0, padx=15)

# # 라벨 : 적립
# lab_updata = Label(win)
# lab_updata.config(text="전화번호 :")
# lab_updata.grid(column=3, row=0, padx=15)

# 입력창 : 조회
ent1=Entry(win)
ent1.config(width=20)
ent1.grid(column=2, row=0, columnspan=2, pady=10)

# # 입력창 : 적립
# ent2=Entry(win)
# ent2.config(width=20)
# ent2.grid(column=4, row=0, pady=10)
# ent.pack(pady=10)
# ent.pack()

#버튼 생성 : 조회
btn1 = Button(win)
btn1.config(width=5, text="조회")
btn1.config(command = select_db)
btn1.grid(column=2, row=1)

#버튼 생성 : 적립
btn2 = Button(win)
btn2.config(width=8, text="적립(+1)")
btn2.config(command = update_db)
btn2.grid(column=2, row=2, pady=10)

# 라벨 : 조회나 적립때 뜨는 완료문
lab2 = Label(win)
result = Label(win)
# 창 실행
win.mainloop()

