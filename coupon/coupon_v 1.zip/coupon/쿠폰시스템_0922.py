#!/usr/bin/env python
# coding: utf-8

# In[22]:


from tkinter import *
import tkinter
from tkinter import messagebox
import pymysql

# db 연결
# 전역변수 선언
conn = None
cur=None
# 테이블 행
row=None

phone = ""
count = ""
first = ""
second = ""
third = ""
fourth = ""
date = ""

# DB 정보
conn = pymysql.connect(host='127.0.0.1', user='root', password='woooo', 
                       db='coupon', charset='utf8')
cur = conn.cursor()
#---------------------------------------------------------------------------

# 창 생성
win = Tk()
# 창 크기 설정
win.geometry("330x450")
win.title("쿠폰적립 시스템")
win.option_add("*Fomt", "맑은고딕30")
# win.configure(bg="red")
# 아이콘 변경
win.iconbitmap('image/logo.ico')
win.iconbitmap(default = 'image/error.ico')

# 프레임 설정
frame1 = Frame(win)
frame2 = Frame(win)

frame1.grid(row=0, column=0, sticky='nsew')
frame2.grid(row=0, column=0, sticky='nsew')

'''
FUNTION
'''
# 프레임 전환 및 컴포넌트 초기화
def changeFrame(frame):
    lab2.config(text="")
    result.config(text="")
    
    lab2_f2.config(text="")
    result_f2.config(text="")
    frame.tkraise()
    
# 쿠폰 적립(신규 경우 등록)
# 쿠폰 적립(신규 경우 등록)
def update_db():
    a = ent1.get()
    if len(a) == 11:
        cur.execute("SELECT * FROM customer WHERE phone ="+ a)
        row=cur.fetchone()
        # 데이터X = 신규
        if row == None:
            cur.execute("INSERT INTO customer(`phone` , `count`) values('"+a+"',1)")
            conn.commit() # 등록 커밋
            result.config(text="고객 등록 완료!")
            result.grid(column=2, row=3, pady=10)

            cur.execute("SELECT * FROM customer WHERE phone LIKE '%" + a + "%'")
            row=cur.fetchone()
            phone = row[0]
            count = row[1]

            lab2.config(text="%s \t %d" %(phone, count) + "\n")
            lab2.grid(column=2, row=4)
            
        else :
            cur.execute("UPDATE customer SET count = count + 1 WHERE phone="+ a)
            cur.execute("SELECT * FROM customer WHERE phone LIKE '%" + a + "%'")
            conn.commit() # 업데이트 커밋
            result.config(text="쿠폰 적립 완료!")
            result.grid(column=2, row=3, pady=10)

            row=cur.fetchone()
            phone = row[0]
            count = row[1]

            lab2.config(text="%s \t %d" %(phone, count) + "\n")
            lab2.grid(column=2, row=4)
    
# 쿠폰 정보 조회    
def select_db():
    a = ent1.get()
    if len(a) <= 11:
        answer=''
        cur.execute("SELECT * FROM customer WHERE phone LIKE '%" + a + "%' LIMIT 10")
        result.config(text="전화번호        쿠폰개수\n-------------------------")
        
        while(True):
            row=cur.fetchone() #한 줄씩
            if row==None :
                break
            phone = row[0]
            count = row[1]
            answer += "%s \t %d" %(phone, count) + "\n"
            
        lab2.config(text=answer)
        
    else :
        result.config(text="전화번호를 확인해주세요")
        lab2.config(text='')
        
#---------------------------------------------------------------------------------                  
# 쿠폰 사용 현황 조회    
def selectUse_db():
    a = ent2.get()
    if len(a) == 11:
        answer=''
        cur.execute("SELECT * FROM customer WHERE phone = "+ a)
        result_f2.config(text="콜라(3)   치즈스틱(5)   쫀득치즈볼(7)   만원할인(10)\n--------------------------------------------------------")
        result_f2.grid(column=0, row=3, columnspan=4, pady=10, padx=15)
        while(True):
            row=cur.fetchone() #한 줄씩
            if row==None :
                break
#             phone = row[0]
#             count = row[1]
            first = row[2]
            second = row[3]
            third = row[4]
            fourth = row[5]
            answer += "%d \t %d \t      %d \t            %d   " %(first, second, third, fourth) + "\n"
        lab2_f2.config(text=answer)
        lab2_f2.grid(column=0, row=4, columnspan=4)
        
    else :
        result_f2.config(text="전화번호를 확인해주세요")
        result_f2.grid(column=1, row=3, columnspan=3, pady=10)
        lab2_f2.config(text='')
        lab2_f2.grid(column=1, row=4)
        
# 쿠폰 사용 내역 조회    
def useDetail_db():
    a = ent2.get()
    if len(a) == 11:
        answer=''
        cur.execute("SELECT * FROM usecoupon WHERE phone ="+ a + " ORDER BY date DESC")
        result_f2.config(text="  사용내역             날짜\n\t-------------------------------------")
        result_f2.grid(column=0, row=3, columnspan=4, pady=10)
        while(True):
            row=cur.fetchone() #한 줄씩
            if row==None :
                break
            use_detail = row[2]
            date = row[3]
            answer += "\t %s \t %s" %(use_detail, date) + "\n"
        lab2_f2.config(text=answer)
        lab2_f2.grid(column=0, row=4, columnspan=4)
        
    else :
        result_f2.config(text="전화번호를 확인해주세요")
        result_f2.grid(column=1, row=3, columnspan=3, pady=10)
        lab2_f2.config(text='')
        lab2_f2.grid(column=1, row=4)
        
# 쿠폰 사용 기능   
# 해당 고객의 사용 내역을 INSERT함
def use_btn():
    phone = ent2.get()
    service = ent3.get()
    # 기존 고객인지 확인
    if (len(phone) == 11 and len(service) > 0):
        cur.execute("SELECT * FROM customer WHERE phone ="+ phone)
        row=cur.fetchone()
        if row == None :
            result_f2.config(text="등록되지 않은 고객입니다")
            result_f2.grid(column=1, row=3, columnspan=3, pady=10)
            lab2_f2.config(text='')
            lab2_f2.grid(column=1, row=4)
    
        else :
            # 칼럼명 변환 전에 사용내역 입력
            # 사용 전 확인 메세지 출력
            MsgBox = messagebox.askquestion("서비스품목 확인 메세지",phone+" 분께 "+service+"을(를) 적립하는게 맞나요?")
            if MsgBox == 'yes':
                cur.execute("INSERT INTO usecoupon (`phone` , `usage_details`, `date`) values('" + phone + "','" + service + "', sysdate())");
                # 어떤 걸 사용했는지 칼럼명으로 변환
                item = "" 
                if "콜라" in service:
                    item = "first"
                    update_usecoupon(phone, item)

                elif "치즈스틱" in service:
                    item = "second"
                    update_usecoupon(phone, item)

                elif "치즈볼" in service:
                    item = "third"
                    update_usecoupon(phone, item)

                elif "할인" in service:
                    item = "fourth"
                    update_usecoupon(phone, item)

                else:
                    result_f2.config(text="서비스 입력을 확인해주세요")
                    result_f2.grid(column=1, row=3, columnspan=3, pady=10)
                    lab2_f2.config(text='')
                    lab2_f2.grid(column=1, row=4)
            else:
                messagebox.showinfo('서비스품목 확인 메세지','한 번 사용하시면 사용 취소가 되지 않으니\n 확인 후 다시 부탁드립니다')
    else:
        # 입력이 안되있으면 오류메세지 출력
        Warn()
        
# 서비스 품목을 잘 입력했다면 사용현황 업데이트
# 이 코드는 customer 테이블에 사용현황을 업데이트 함
def update_usecoupon(phone, item):
    cur.execute("UPDATE customer SET " + item + "=" + item + "+1 WHERE phone="+ phone)
    conn.commit() # 업데이트 커밋
    result_f2.config(text="★☆ 쿠폰사용 완료 ★☆")
    result_f2.grid(column=1, row=3, columnspan=3, pady=10)
    lab2_f2.config(text='(사용내역에서 확인해주세요)')
    lab2_f2.grid(column=1, row=4, columnspan=3)

'''
COMPONENTS : FRAME 1(적립)
'''
# 나름 꾸미기..?
# can = Canvas(win, bg='green')
# can.grid(column=0, row=0)

# 라벨 : 조회
lab = Label(frame1)
lab.config(width=15, text="전화번호 :")
lab.grid(column=0, row=0, columnspan=1)

# 입력창 : 조회
ent1=Entry(frame1)
ent1.config(width=20, border=0.5, relief='solid')
ent1.grid(column=2, row=0, columnspan=2, pady=10)

#버튼 생성 : 조회
btn1 = Button(frame1)
btn1.config(width=8, text="조회")
btn1.config(command = select_db)
btn1.grid(column=2, row=1)

#버튼 생성 : 적립
btn2 = Button(frame1)
btn2.config(width=8, text="적립(+1)")
btn2.config(command = update_db)
btn2.grid(column=3, row=1, pady=10)

#버튼 이미지 생성
photo = PhotoImage(file="image/bcoupon.png")
#버튼 생성 : 프레임 전환
usebtn = Button(frame1, image=photo)
usebtn.config(width=138, text="쿠폰 사용")
usebtn.config(command = lambda:[changeFrame(frame2)])
usebtn.grid(column=2, row=5, columnspan=2, pady=10)

# 라벨 : 조회나 적립때 뜨는 완료문
lab2 = Label(frame1)
lab2.grid(column=2, row=3, columnspan=2)

result = Label(frame1)
result.grid(column=2, row=2, columnspan=2, pady=10)        

'''
COMPONENTS : FRAME 2(사용내역)
'''
# 라벨 : 조회
lab= Label(frame2)
lab.config(width=10, text="전화번호 :")
lab.grid(column=0, row=0)

# 입력창 : 조회
ent2=Entry(frame2)
ent2.config(width=25, border=0.5, relief='solid')
ent2.grid(column=1, row=0, columnspan=3, pady=10)

# 서비스 입력 코드
service= Label(frame2)
service.config(width=15, text="서비스 :")
service.grid(column=0, row=1)
    
ent3=Entry(frame2)
ent3.config(width=25, border=0.5, relief='solid')
ent3.grid(column=1, row=1, columnspan=3)

#버튼 생성 : 조회
btn = Button(frame2)
btn.config(width=8, text="사용")
btn.config(command = use_btn)
btn.grid(column=1, row=2, pady=10)

#버튼 생성 : 조회
btn1 = Button(frame2)
btn1.config(width=8, text="사용현황")
btn1.config(command = selectUse_db)
btn1.grid(column=2, row=2)

#버튼 생성 : 조회
btn2 = Button(frame2)
btn2.config(width=8, text="사용내역")
btn2.config(command = useDetail_db)
btn2.grid(column=3, row=2)

#버튼 이미지 생성
photo2 = PhotoImage(file="image/bchick.png")
#버튼 생성 : 프레임 전환
usebtn = Button(frame2, image=photo2)
usebtn.config(width=140, text="쿠폰적립")
usebtn.config(command = lambda:[changeFrame(frame1)])
usebtn.grid(column=1, row=5, columnspan=3, pady=10)

# 라벨2 : 조회 및 사용 내역 결과
lab2_f2 = Label(frame2)

result_f2 = Label(frame2)
result_f2.grid(column=1, row=3, columnspan=2, pady=10,  padx=15)

''' 공통 COMPONENT '''
# 경고창
def Warn():
    MsgBox = messagebox.showwarning("쿠폰사용 오류", "전화번호와 서비스 모두 입력해야 쿠폰 사용이 가능합니다")
#     if MsgBox == 'yes':
#        root.destroy()
#     else:
#         tk.messagebox.showinfo('Welcome Back','Welcome back to the App')
        
# 창 실행
changeFrame(frame1) # 기본 화면
win.mainloop()